/**
 * � Copyright IBM Corporation 2018.
 * � Copyright HCL Technologies Ltd. 2018.
 * LICENSE: Apache License, Version 2.0 https://www.apache.org/licenses/LICENSE-2.0
 */
package common

import javax.net.ssl.*;
import java.security.cert.*;
import groovy.json.JsonSlurper;

/**
 * Some REST Utilities which may be handy.  These will likely need to be generalized to be more broadly useful
 * For example, generalized content type handling, generalized response handling, etc
 */
class RESTUtils {

	static
	{
		TrustManager[] trustAllCerts = [
			new X509ExtendedTrustManager() {
				@Override
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				@Override
				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}

				@Override
				public void checkClientTrusted(X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

				}

				@Override
				public void checkServerTrusted(X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

				}

				@Override
				public void checkClientTrusted(X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

				}

				@Override
				public void checkServerTrusted(X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

				}

			}] as TrustManager[];


		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new java.security.SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		// Create all-trusting host name verifier
		HostnameVerifier allHostsValid = new HostnameVerifier() {
			@Override
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};
		// Install the all-trusting host verifier
		HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	}
	
	//Returns the text of the response (or error messages).  It is up to callers of this method to parse and handle the JSON coming back
	public static postWithJSON(apiURL, authorization, jsonPayload, headers, List<String> errors) {

		def connection = apiURL.toURL().openConnection()
		connection.addRequestProperty("Authorization", authorization)
		connection.addRequestProperty("Content-Type", "application/json")
		if (headers != null) {
			for (String headerKey : headers.keySet()) {
				connection.addRequestProperty(headerKey, headers.get(headerKey))
			}
		}
		connection.setRequestMethod("POST")
		connection.doOutput = true
		connection.outputStream.withWriter {
			it.write(jsonPayload)
			it.flush()
		}
		connection.connect()

		try {
			def responseText = connection.content.text
			return responseText
		} catch (IOException e) {
			try {
				System.out.println("postWithJSON = "+e.getMessage());
				errors.add("An error occured while communicating with tracking system: " + ((HttpURLConnection) connection).errorStream.text)
			} catch (Exception f) {
				errors.add("An error occured while communicating with tracking system: " + e.getMessage() + " & " + f.getMessage())
				System.out.println("An error occured while communicating with tracking system: " + e.getMessage() + " & " + f.getMessage());
			}
		}
	}

	//Returns the text of the response (or error messages).  It is up to callers of this method to parse and handle the JSON coming back
	public static patchWithJSON(apiURL, authorization, jsonPayload, headers, List<String> errors) {

		def connection = apiURL.toURL().openConnection()
		connection.addRequestProperty("Authorization", authorization)
		connection.addRequestProperty("Content-Type", "application/json-patch+json")
		if (headers != null) {
			for (String headerKey : headers.keySet()) {
				connection.addRequestProperty(headerKey, headers.get(headerKey))
			}
		}
		connection.setRequestProperty("X-HTTP-Method-Override", "PATCH");
		connection.setRequestMethod("POST")
		connection.doOutput = true
		connection.outputStream.withWriter {
			it.write(jsonPayload)
			it.flush()
		}
		connection.connect()

		try {
			def responseText = connection.content.text
			return responseText
		} catch (IOException e) {
			try {
				errors.add("An error occured while communicating with tracking system: " + ((HttpURLConnection) connection).errorStream.text)
			} catch (Exception f) {
				errors.add("An error occured while communicating with tracking system: " + e.getMessage() + " & " + f.getMessage())
			}
		}
	}

	public static postMultiPartFileUpload(apiURL, authorization, filePayload, fileName, headers, List<String> errors) {

		String boundaryString = "AppScanRandom123512351213";

		def connection = apiURL.toURL().openConnection()
		connection.addRequestProperty('Authorization', authorization)
		connection.addRequestProperty('X-Atlassian-Token', 'no-check')
		if (headers != null) {
			for (String headerKey : headers.keySet()) {
				connection.addRequestProperty(headerKey, headers.get(headerKey))
			}
		}
		connection.addRequestProperty("Content-Type", 'multipart/form-data; boundary=' + boundaryString)
		connection.setRequestMethod("POST")
		connection.doOutput = true
		connection.doInput = true

		connection.outputStream.withWriter {
			def thePart = generatePart(filePayload, fileName, boundaryString)
			it.write(thePart)
			it.flush()
		}
		connection.connect()

		try {
			connection.content.text
		} catch (IOException e) {
			try {
				errors.add("An error occured while communicating with tracking system: " + ((HttpURLConnection) connection).errorStream.text)
			} catch (Exception f) {
				errors.add("An error occured while communicating with tracking system: " + e.getMessage() + " & " + f.getMessage())
			}
		}
	}

	public static postOctetStreamFileUpload(apiURL, authorization, filePayload, headers, List<String> errors) {

		String boundaryString = "AppScanRandom123512351213";

		def connection = apiURL.toURL().openConnection()
		connection.addRequestProperty('Authorization', authorization)

		if (headers != null) {
			for (String headerKey : headers.keySet()) {
				connection.addRequestProperty(headerKey, headers.get(headerKey))
			}
		}
		//connection.addRequestProperty("Content-Type", 'multipart/form-data; boundary=' + boundaryString)
		connection.addRequestProperty("Content-Type", "application/octet-stream")
		connection.setRequestMethod("POST")
		connection.doOutput = true
		connection.doInput = true

		connection.outputStream.withWriter {
			def theFile = generateOctetStream(filePayload)
			it.write(theFile)
			it.flush()
		}
		connection.connect()

		try {
			def octetPostResponseText = connection.content.text
			return octetPostResponseText
		} catch (IOException e) {
			try {
				errors.add("An error occured while communicating with tracking system: " + ((HttpURLConnection) connection).errorStream.text)
			} catch (Exception f) {
				errors.add("An error occured while communicating with tracking system: " + e.getMessage() + " & " + f.getMessage())
			}
		}
	}

	private static String generatePart(File theFile, String fileName, String boundaryString) {
		StringBuffer buf = new StringBuffer();
		buf.append("--" + boundaryString + "\r\n")
		buf.append("Content-Disposition: form-data; name=\"file\"; filename=\"" + fileName + "\"\r\n");
		buf.append("\nContent-Type: text/html\r\n");
		buf.append("\r\n");
		// Write the actual file contents
		BufferedReader br = new BufferedReader(new FileReader(theFile))
		String nextLine = null;
		while ((nextLine = br.readLine()) != null) {
			buf.append(nextLine + "\r\n");
		}

		// Mark the end of the multipart http request
		buf.append("--" + boundaryString + "--\r\n");
		return buf.toString();
	}

	private static String generateOctetStream(File theFile) {
		StringBuffer buf = new StringBuffer();

		// Write the actual file contents
		BufferedReader br = new BufferedReader(new FileReader(theFile))
		String nextLine = null;
		while ((nextLine = br.readLine()) != null) {
			buf.append(nextLine + "\r\n");
		}

		return buf.toString();

	}

}
